import { Component } from '@angular/core';
import { IonicPage, NavController, NavParams } from 'ionic-angular';
import { RemoteServiceProvider } from '../../providers/remote-service/remote-service';
import { AlertController, App} from 'ionic-angular';
import { ToastController } from 'ionic-angular';
import { Storage } from '@ionic/storage';
import {Observable} from 'rxjs/Rx';
import { Subscription } from "rxjs/Subscription";
import { HomePage } from '../home/home';

@IonicPage()
@Component({
  selector: 'page-add-zones',
  templateUrl: 'add-zones.html',
})
export class AddZonesPage {

    public types:any;
    public observableVar:any;

  constructor(public navCtrl: NavController,
            public navParams: NavParams,
            public remoteService : RemoteServiceProvider,
            public alertCtrl: AlertController,
            public toastCtrl: ToastController,
            public appCtrl: App,
            public storage: Storage) {
  }

  name;
  type;

  ionViewWillEnter(){
      this.getTypes();
  }

  menu(){
        this.navCtrl.push(HomePage);
  }

  addZone(){
      this.storage.get('iduser').then((iduser) => {
          this.remoteService.postApiAddZones(iduser,this.name,this.type)
          .then((response) => {
            if(response == true){
                this.messageInfo("Zona agregada correctamente");
                this.navCtrl.pop();
            }
            else{
                this.messageInfo("Error al agregar la zona");
            }
        });
      });
  }

  ionViewDidLoad() {
  }

  getTypes() : any{
    this.observableVar = Subscription;
    this.remoteService.getApiZonesType()
    .then(data => {
      this.types = data;
    });
  }

  messageInfo(message) {
      let toast = this.toastCtrl.create({
        message: message,
        duration: 3000,
        position: 'buttom'
      });

      toast.onDidDismiss(() => {

      });

      toast.present();
    }
}
