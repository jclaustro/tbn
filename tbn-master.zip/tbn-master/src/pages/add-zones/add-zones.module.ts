import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { AddZonesPage } from './add-zones';

@NgModule({
  declarations: [
    AddZonesPage,
  ],
  imports: [
    IonicPageModule.forChild(AddZonesPage),
  ],
})
export class AddZonesPageModule {}
