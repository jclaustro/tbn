import { Component } from '@angular/core';
import { IonicPage, NavController, NavParams,ModalController, Config, AlertController, App } from 'ionic-angular';

import { ZonesPage } from '../zones/zones';
import { EquipmentsPage } from '../equipments/equipments';
import { AccountPage } from '../account/account';
import { BarcodePage } from '../barcode/barcode';
import { TipsPage } from '../tips/tips';
import { InventoryPage } from '../inventory/inventory';
import { StatsPage } from '../stats/stats';
import { Storage } from '@ionic/storage';

@Component({
  selector: 'page-home',
  templateUrl: 'home.html'
})
export class HomePage {
    zonePage = ZonesPage;
    equipmentPage = EquipmentsPage;
    accountPage = AccountPage;
    barcodePage = BarcodePage;
    tipsPage = TipsPage;
    inventoryPage = InventoryPage;
    statsPage = StatsPage;
    public userType:any;

  constructor(public navCtrl: NavController,
      public navParams: NavParams,
      public alertCtrl: AlertController,
      public config: Config,
      public appCtrl: App,
      public modalCtrl: ModalController,
      public storage: Storage) {

  }

  ionViewDidEnter(){
    this.storage.get('userType').then((userType) => {
      this.userType = userType;
    });
  }
}
