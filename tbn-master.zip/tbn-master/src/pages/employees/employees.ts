import { Component } from '@angular/core';
import { IonicPage, NavController, NavParams } from 'ionic-angular';
import { RemoteServiceProvider } from '../../providers/remote-service/remote-service';
import { Subscription } from "rxjs/Subscription";
import { Storage } from '@ionic/storage';
import { ToastController } from 'ionic-angular';
import { AddEmployeePage } from '../add-employee/add-employee';

@IonicPage()
@Component({
  selector: 'page-employees',
  templateUrl: 'employees.html',
})
export class EmployeesPage {

  public observableVar: any;
  public employees:any;

  constructor(public navCtrl: NavController,
              public navParams: NavParams,
              public remoteService: RemoteServiceProvider,
              public storage: Storage,
              public toastCtrl: ToastController) {}

  ionViewDidEnter(){
    this.getSubUsers();
  }

  getSubUsers() : any{
    this.storage.get('iduser').then((iduser) => {
      this.observableVar = Subscription;
      this.remoteService.getApiSubUsers(iduser)
        .then((response) => {
          /*if(response == false){
            this.messageInfo("No hay Empleados para mostrar");
          }else{
            this.employees = response;
          }*/
          this.employees = response;
        });
    });
  }

  addEmployee(){
    this.navCtrl.push(AddEmployeePage);
  }

  updateEmployee(){

  }

  deleteEmployee(employee){
    console.log(employee);
    this.remoteService.postApiDeleteSubUserByIdSubUser(employee.idsubuser)
      .then((response) => {
        if(response == false){
          this.messageInfo("Faltan datos");
        }else{
          this.messageInfo("Eliminado correctamente");
          this.ionViewDidEnter();
        }
      });
  }

  messageInfo(message) {
    let toast = this.toastCtrl.create({
      message: message,
      duration: 3000,
      position: 'buttom'
    });
    toast.onDidDismiss(() => {
    });
    toast.present();
  }
}
