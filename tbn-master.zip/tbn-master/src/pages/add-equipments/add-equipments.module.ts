import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { AddEquipmentsPage } from './add-equipments';

@NgModule({
  declarations: [
    AddEquipmentsPage,
  ],
  imports: [
    IonicPageModule.forChild(AddEquipmentsPage),
  ],
})
export class AddEquipmentsPageModule {}
