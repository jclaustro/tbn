import { Component } from '@angular/core';
import { IonicPage, NavController, NavParams } from 'ionic-angular';
import { AlertController, App} from 'ionic-angular';
import { HomePage } from '../home/home';
import { RemoteServiceProvider } from '../../providers/remote-service/remote-service';
import {Observable} from 'rxjs/Rx';
import { Subscription } from "rxjs/Subscription";
import { Storage } from '@ionic/storage';
import { BarcodeScanner, BarcodeScannerOptions } from '@ionic-native/barcode-scanner';
import { ToastController } from 'ionic-angular';

@IonicPage()
@Component({
  selector: 'page-add-equipments',
  templateUrl: 'add-equipments.html',
})
export class AddEquipmentsPage {

 public equipment:any;
 public equipmentRes:any;
 public brands: any;
 public types:any;
 public zones:any;
 public observableVar:any;

  options :BarcodeScannerOptions;

  constructor(public navCtrl: NavController,
      public navParams: NavParams,
      public remoteService : RemoteServiceProvider,
      public barcodeScanner: BarcodeScanner,
      public toastCtrl: ToastController,
      public storage: Storage) {
  }

  type;
  brand;
  model;
  dcinput;
  dcoutput;
  watts;
  amperes;
  zone;
  barcode;
  use;


  addEquipment(){
        this.equipment ={
          "type": this.type,
          "brand": this.brand,
          "barcode": this.barcode,
          "model" : this.model,
          "dcinput": this.dcinput,
          "dcoutput": this.dcoutput,
          "watts": this.watts,
          "use": this.use,
          "amperes" : this.amperes,
          "zone": this.zone
        };

        this.storage.get('iduser').then((iduser) => {
            this.remoteService.postApiAddEquipment(this.equipment,iduser)
            .then((response) => {
              console.log(response);
              if(response == true)
              {
                  this.messageInfo("Equipo agregado correctamente");
                  this.navCtrl.pop();
              }
          });
        });
  }

  menu(){
      this.navCtrl.setRoot(HomePage);
  }

  ionViewDidLoad() {

  }

  ionViewWillEnter(){
      this.getBrands();
      this.getTypes();
      this.getZones();
  }

  scan() {
      this.options = {
       prompt : "Escanea tu codigo de barras",
       showFlipCameraButton: true,
       showTorchButton: true,
       orientation: "portrait"
   }

      this.barcodeScanner.scan(this.options).then(barcodeData => {
          this.barcode = barcodeData.text;
          this.search(0);

    }).catch(err => {
        this.messageInfo(err);
    });
  }

  search(val){
      if(this.barcode == undefined || val == 1){
          this.barcode = "";
      }

      if(this.model == undefined || val == 0){
          this.model = "";
      }

      if(this.model != "" || this.barcode != ""){
          this.remoteService.postApiSearchEquipment(this.barcode,this.model)
            .then((response) => {
              if(response == "noModel"){
                  this.messageInfo("No se encontro ese modelo");
                  this.clearFields();
                  this.barcode = "";
              }
              if(response == "noBarcode"){
                  this.messageInfo("No se encontro ese codigo de barras");
                  this.clearFields();
                  this.model = "";
              }
              if(response == "noInformation"){
                  this.messageInfo("No se capturo ningun dato");
              }
              if(response != "noModel" && response != "noBarcode" && response != "noInformation"){
                  this.barcode = response[0].barcode;
                  this.type = response[0].type;
                  this.brand = response[0].brand;
                  this.model = response[0].model;
                  this.dcinput = response[0].dcinput;
                  this.dcoutput = response[0].dcoutput;
                  this.watts = response[0].watts;
                  this.amperes = response[0].amperes;
              }
        });

    }else{
        this.messageInfo("No hay datos que buscar");
    }
  }

  clearFields(){
      this.type = "";
      this.brand = "";
      this.dcinput = "";
      this.dcoutput = "";
      this.watts = "";
      this.amperes = "";
  }

  messageInfo(message) {
      let toast = this.toastCtrl.create({
        message: message,
        duration: 3000,
        position: 'buttom'
      });

      toast.onDidDismiss(() => {
      });

      toast.present();
    }

  getBrands() : any{
    this.observableVar = Subscription;
    this.remoteService.getApiBrands()
    .then(data => {
      this.brands = data;
    });
  }

  getTypes() : any{
    this.observableVar = Subscription;
    this.remoteService.getApiEquipmentsType()
    .then(data => {
      this.types = data;
    });
  }

  getZones() : any{
      this.storage.get('iduser').then((iduser) => {
          this.observableVar = Subscription;
          this.remoteService.getApiUserZones(iduser)
          .then(data => {
            this.zones = data;
          });
      });
  }

}
