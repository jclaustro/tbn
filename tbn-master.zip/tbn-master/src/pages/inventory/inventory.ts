import { Component } from '@angular/core';
import { IonicPage, NavController, NavParams } from 'ionic-angular';
import { RemoteServiceProvider } from '../../providers/remote-service/remote-service';
import {Observable} from 'rxjs/Rx';
import { Subscription } from "rxjs/Subscription";
import { AlertController, LoadingController } from 'ionic-angular';
import { Storage } from '@ionic/storage';
import { InventoryDetailsPage } from '../inventory-details/inventory-details';
import { ToastController } from 'ionic-angular';

@IonicPage()
@Component({
  selector: 'page-inventory',
  templateUrl: 'inventory.html',
})
export class InventoryPage {
    public inventories:any;
    public observableVar: any;
    public inventory:any;

  constructor(public navCtrl: NavController,
      public navParams: NavParams,
      public remoteService: RemoteServiceProvider,
      public alertCtrl: AlertController,
      public loading: LoadingController,
      public storage: Storage,
      public toastCtrl: ToastController) {
  }

  ionViewDidLoad() {

  }

  ionViewDidEnter(){
      this.getInventory();
  }

  getInventory() : any{
      this.storage.get('iduser').then((iduser) => {
          this.observableVar = Subscription;
          this.remoteService.getApiInventory(iduser)
          .then(data => {
            this.inventories = data;
            //data !== null ? this.inventories = data : this.messageInfo("No se encontro ningun inventario");
          });
     });
 }

  openEquipments(inventory){
     this.navCtrl.push(InventoryDetailsPage,{
         "type" : inventory.type
      });
  }

  messageInfo(message) {
      let toast = this.toastCtrl.create({
        message: message,
        duration: 3000,
        position: 'buttom'
      });
      toast.onDidDismiss(() => {
      });
      toast.present();
    }
}
