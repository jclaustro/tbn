import { Component } from '@angular/core';
import { IonicPage, NavController, NavParams } from 'ionic-angular';
import { RemoteServiceProvider } from '../../providers/remote-service/remote-service';
import {Observable} from 'rxjs/Rx';
import { Subscription } from "rxjs/Subscription";
import { AlertController, LoadingController } from 'ionic-angular';
import { HomePage } from '../home/home';
import { EquipmentsDetailsPage } from '../equipments-details/equipments-details';
import { Storage } from '@ionic/storage';
import { ToastController } from 'ionic-angular';

@IonicPage()
@Component({
  selector: 'page-inventory-details',
  templateUrl: 'inventory-details.html',
})
export class InventoryDetailsPage {

    public details:any;
    public type:any;
    public observableVar: any;

  constructor(public navCtrl: NavController,
      public navParams: NavParams,
      public remoteService: RemoteServiceProvider,
      public alertCtrl: AlertController,
      public loading: LoadingController,
      public storage: Storage,
      public toastCtrl: ToastController) {
      this.type = this.navParams.get('type');
  }

  ionViewDidLoad() {
  }

  ionViewDidEnter(){
    this.getInventoryDetails();
  }

  menu(){
      this.navCtrl.setRoot(HomePage);
  }

  openEquipments(email,type){
      this.remoteService.postApiInventoryDetails(email,type)
      .then((response)  => {
       this.details = response;
    });
  }

  openEquipment(equipment){
      /*this.navCtrl.push(EquipmentsDetailsPage,{
        "equipmentDetails" : equipment
      });*/
  }

  getInventoryDetails() : any{
    this.storage.get('iduser').then((iduser) => {
      this.observableVar = Subscription;
      this.remoteService.getApiInventoryDetails(iduser,this.type)
        .then(data => {
          this.details = data;
          //data !== null ?  this.details = data : this.messageInfo("No se encontro ningun detalle");
        });
    });
  }

  messageInfo(message) {
      let toast = this.toastCtrl.create({
        message: message,
        duration: 3000,
        position: 'buttom'
      });
      toast.onDidDismiss(() => {
      });
      toast.present();
    }
}
