import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { InventoryDetailsModelPage } from './inventory-details-model';

@NgModule({
  declarations: [
    InventoryDetailsModelPage,
  ],
  imports: [
    IonicPageModule.forChild(InventoryDetailsModelPage),
  ],
})
export class InventoryDetailsModelPageModule {}
