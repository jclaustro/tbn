import { Component } from '@angular/core';
import { IonicPage, NavController, NavParams } from 'ionic-angular';
import { Storage } from '@ionic/storage';
import { HomePage } from '../home/home';
import { LoginPage } from '../login/login';
import { EmployeesPage } from '../employees/employees';
import { UpdateAccountPage } from '../update-account/update-account';
import { AlertController } from 'ionic-angular';

@IonicPage()
@Component({
  selector: 'page-account',
  templateUrl: 'account.html',
})
export class AccountPage {
  constructor(public navCtrl: NavController,
              public navParams: NavParams,
              public storage: Storage,
              public alertCtrl: AlertController) {
  }

  email;
  password;
  status;
  iduser;
  company;
  userType;

  ionViewDidLoad() {
    this.storage.get('email').then((val) => {
      this.email = val;
    });

    this.storage.get('company').then((val) => {
      this.company = val;
    });

    this.storage.get('password').then((val) => {
      this.password = val;
    });

    this.storage.get('iduser').then((val) => {
      this.iduser = val;
    });

    this.storage.get('userStatus').then((val) => {
      this.status = val;
    });

    this.storage.get('userType').then((userType) => {
      this.userType = userType;
    });
  }

  closeSesion(){
    let alert = this.alertCtrl.create({
      title: 'Cerrar Sesion',
      message: 'Realmente deseas cerrar sesion?',
      buttons: [
        {
          text: 'No',
          role: 'cancel',
          handler: () => {
          }
        },
        {
          text: 'Si',
          handler: () => {
            this.storage.set('userStatus', 0);
            this.navCtrl.setRoot(LoginPage);
          }
        }
      ]
    });
    alert.present();
  }

  updateInfo(){
    this.navCtrl.push(UpdateAccountPage);
  }

  showEmployees(){
    this.navCtrl.push(EmployeesPage);
  }
}
