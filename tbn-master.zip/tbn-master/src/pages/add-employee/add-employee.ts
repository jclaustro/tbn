import { Component } from '@angular/core';
import { IonicPage, NavController, NavParams } from 'ionic-angular';
import { RemoteServiceProvider } from '../../providers/remote-service/remote-service';
import { ToastController } from 'ionic-angular';
import { Storage } from '@ionic/storage';
import {Observable} from 'rxjs/Rx';
import { Subscription } from "rxjs/Subscription";

@IonicPage()
@Component({
  selector: 'page-add-employee',
  templateUrl: 'add-employee.html',
})
export class AddEmployeePage {

    public observableVar:any;
    public types:any;
    public employee:any;
    public iduser:any;
    public company: any;

  constructor(public navCtrl: NavController,
      public navParams: NavParams,
      public remoteService : RemoteServiceProvider,
      public toastCtrl: ToastController,
      public storage: Storage) {
  }

  type;
  email;
  password;
  repitpassword;

  ionViewDidLoad() {

  }

  ionViewWillEnter(){
      this.getTypes();

      this.storage.get('iduser').then((iduser) => {
          this.iduser = iduser;
      });
      this.storage.get('company').then((company) => {
          this.company = company;
      });
  }

  addEmployee(): any{
      if(this.password != this.repitpassword){
          this.messageInfo("Las Contraseñas no Coinciden");
          this.password = "";
          this.repitpassword = "";
      }else{
          this.employee = {
              "type": this.type,
              "email": this.email,
              "password": this.password,
              "iduser": this.iduser,
              "company": this.company
          };

          this.remoteService.postApiAddSubUsers(this.employee)
          .then((response) => {
            if(response == true){
                this.messageInfo("Empleado agregado correctamente");
                this.navCtrl.pop();
            }
        });
      }
  }

  getTypes() : any{
    this.observableVar = Subscription;
    this.remoteService.getApiUsersType()
    .then(data => {
      this.types = data;
    });
  }

  messageInfo(message) {
      let toast = this.toastCtrl.create({
        message: message,
        duration: 3000,
        position: 'buttom'
      });

      toast.onDidDismiss(() => {

      });

      toast.present();
    }
}
