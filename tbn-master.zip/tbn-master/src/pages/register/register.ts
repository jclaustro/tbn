import { Component } from '@angular/core';
import { IonicPage, NavController, NavParams } from 'ionic-angular';
import { RemoteServiceProvider } from '../../providers/remote-service/remote-service';
import { AlertController, App} from 'ionic-angular';
import { ToastController } from 'ionic-angular';
import {Observable} from 'rxjs/Rx';
import { Subscription } from "rxjs/Subscription";
import { Storage } from '@ionic/storage';

@IonicPage()
@Component({
  selector: 'page-register',
  templateUrl: 'register.html',
})
export class RegisterPage {
  public observableVar:any;
  public states:any;
  public types:any;
  public municipalities:any;

  constructor(public navCtrl: NavController,
      public navParams: NavParams,
      public remoteService : RemoteServiceProvider,
      public alertCtrl: AlertController,
      private toastCtrl: ToastController,
      public appCtrl: App) {
  }

email;
password;
passwordA;
company;
state;
municipality;
userType;
type;
ticket;

  ionViewDidLoad() {

  }

  ionViewWillEnter(){
      this.getStates();
      this.getTypes();
  }

  register(){
      if(this.password != this.passwordA){
            this.messageInfo("Las Contraseñas no Coinciden");
            this.password = "";
            this.passwordA = "";
        }
        else{
            this.remoteService.postApiUserRegister(this.email, this.password, this.company,this.state,this.municipality,this.type,this.ticket)
            .then((response) => {
                if(response == true){
                     this.messageInfo("Usuario Registrado Correctamente");
                     this.navCtrl.pop();
                }
                else{
                    this.messageInfo("Usuario " + this.email + " " + "ya esta registrado");
                }
              });
        }
  }

  getStates() : any{
    this.observableVar = Subscription;
    this.remoteService.getApiStates()
    .then(data => {
      this.states = data;
    });
  }

  getTypes() : any{
    this.observableVar = Subscription;
    this.remoteService.getApiUsersType()
    .then(data => {
      this.types = data;
    });
  }

  loadMunicipalities(idstate){
    this.remoteService.getApiMunicipalitiesByIdState(idstate)
      .then((response) => {
        if(response == false){
          this.messageInfo("No se encontraron municipios");
        }
        else{
          this.municipalities = response;
        }
      });
  }

  messageInfo(message) {
      let toast = this.toastCtrl.create({
        message: message,
        duration: 3000,
        position: 'buttom'
      });
      toast.onDidDismiss(() => {
      });
      toast.present();
    }
}
