import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { ZonesPage } from './zones';

@NgModule({
  declarations: [
    ZonesPage,
  ],
  imports: [
    IonicPageModule.forChild(ZonesPage),
  ],
})
export class ZonesPageModule {}
