import { Component, ViewChild } from '@angular/core';
import { IonicPage, NavController, NavParams } from 'ionic-angular';
import { Chart } from 'chart.js';
import { RemoteServiceProvider } from '../../providers/remote-service/remote-service';
import {Observable} from 'rxjs/Rx';
import { Subscription } from "rxjs/Subscription";
import { AlertController, LoadingController } from 'ionic-angular';
import { Storage } from '@ionic/storage';
import { ToastController } from 'ionic-angular';
import { AddZonesPage } from '../add-zones/add-zones';
import { ZonesDetailsPage } from '../zones-details/zones-details';


@IonicPage()
@Component({
  selector: 'page-zones',
  templateUrl: 'zones.html',
})
export class ZonesPage {

    public user:any;
    public observableVar: any;
    public zones: any;

  constructor(public navCtrl: NavController,
      public navParams: NavParams,
      public remoteService: RemoteServiceProvider,
      public alertCtrl: AlertController,
      public loading: LoadingController,
      public storage: Storage,
      public toastCtrl: ToastController) {

  }

  addZone(){
        this.navCtrl.push(AddZonesPage);
  }

  details(zonename){
      this.navCtrl.push(ZonesDetailsPage, {
      "zonen": zonename
    });
  }

  ionViewDidEnter(){
      this.getUserZones();
  }

  ionViewDidLoad() {
  }

  getUserZones() : any{
      this.storage.get('iduser').then((iduser) => {
          this.observableVar = Subscription;
          this.remoteService.getApiUserZones(iduser)
          .then(data => {
              /*if(data == false){
                  this.messageInfo("Aun no hay zonas registradas");
              }else{
                this.zones = data;
              }*/
              this.zones = data;
          });
      });
  }

  deleteZone(zone){
    console.log(zone.idzone);
    this.remoteService.postApiDeleteZoneByIdZone(zone.idzone)
      .then((response) => {
        if(response == "deleted"){
          this.messageInfo("Eliminado correctamente");
          this.ionViewDidEnter();
        }else{
          this.messageInfo(response);
        }
      });
  }

  messageInfo(message) {
      let toast = this.toastCtrl.create({
        message: message,
        duration: 3000,
        position: 'buttom'
      });
      toast.onDidDismiss(() => {
      });
      toast.present();
    }
}
