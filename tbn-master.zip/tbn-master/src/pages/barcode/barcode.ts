import { Component } from '@angular/core';
import { IonicPage, NavController, NavParams } from 'ionic-angular';
import { BarcodeScanner, BarcodeScannerOptions } from '@ionic-native/barcode-scanner';
import { ToastController } from 'ionic-angular';

@IonicPage()
@Component({
  selector: 'page-barcode',
  templateUrl: 'barcode.html',
})
export class BarcodePage {
    options :BarcodeScannerOptions;
  constructor(public navCtrl: NavController,
              public navParams: NavParams,
              public barcodeScanner: BarcodeScanner,
              public toast: ToastController) {
  }

  barcode;
  scan() {
      this.options = {
       prompt : "Escanea tu codigo de barras",
       showFlipCameraButton: true,
       showTorchButton: true,
       orientation: "portrait"
   }

      this.barcodeScanner.scan(this.options).then(barcodeData => {
          this.presentToast(barcodeData.text);
          this.barcode = barcodeData.text;

    }).catch(err => {

        this.presentToast(err);
    });
}

presentToast(text) {
  let toast = this.toast.create({
    message: text,
    duration: 3000,
    position: 'button'
  });

  toast.onDidDismiss(() => {

  });
  toast.present();
}

}
