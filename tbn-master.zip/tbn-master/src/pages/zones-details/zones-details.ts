import { Component } from '@angular/core';
import { IonicPage, NavController, NavParams } from 'ionic-angular';
import { RemoteServiceProvider } from '../../providers/remote-service/remote-service';
import {Observable} from 'rxjs/Rx';
import { Subscription } from "rxjs/Subscription";
import { EquipmentsDetailsPage } from '../equipments-details/equipments-details';
import { Storage } from '@ionic/storage';
import { ToastController } from 'ionic-angular';

@IonicPage()
@Component({
  selector: 'page-zones-details',
  templateUrl: 'zones-details.html',
})
export class ZonesDetailsPage {
    public zonename:any;
    public equipments:any;
    public user:any;
    public observableVar: any;

  constructor(public navCtrl: NavController,
      public navParams: NavParams,
      public storage: Storage,
      public remoteService: RemoteServiceProvider,
      public toastCtrl: ToastController) {
      this.zonename = navParams.get("zonen");
  }

  ionViewDidLoad() {
    this.getZonesDetails();
  }


  getZonesDetails() : any{
    this.storage.get('iduser').then((iduser) => {
      this.observableVar = Subscription;
      this.remoteService.getApiZonesDetails(iduser,this.zonename)
        .then(data => {
          if(data == false){
            this.messageInfo("Aun no hay zonas registradas");
          }else{
            this.equipments = data;
          }
        });
    });
  }

  messageInfo(message) {
      let toast = this.toastCtrl.create({
        message: message,
        duration: 3000,
        position: 'buttom'
      });
      toast.onDidDismiss(() => {
      });
      toast.present();
    }

  openEquipment(equipment){
    this.navCtrl.push(EquipmentsDetailsPage,
      {
        equipmentDetails: equipment
      });
  }
}
