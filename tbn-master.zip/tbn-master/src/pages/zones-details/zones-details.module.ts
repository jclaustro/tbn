import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { ZonesDetailsPage } from './zones-details';

@NgModule({
  declarations: [
    ZonesDetailsPage,
  ],
  imports: [
    IonicPageModule.forChild(ZonesDetailsPage),
  ],
})
export class ZonesDetailsPageModule {}
