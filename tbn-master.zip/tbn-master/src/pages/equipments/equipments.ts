import { Component } from '@angular/core';
import { IonicPage, NavController, NavParams } from 'ionic-angular';
import { RemoteServiceProvider } from '../../providers/remote-service/remote-service';
import { Subscription } from "rxjs/Subscription";
import { AlertController, LoadingController } from 'ionic-angular';
import { AddEquipmentsPage } from '../add-equipments/add-equipments';
import { EquipmentsDetailsPage } from '../equipments-details/equipments-details';
import { Storage } from '@ionic/storage';
import { ToastController } from 'ionic-angular';

@IonicPage()
@Component({
  selector: 'page-equipments',
  templateUrl: 'equipments.html',
})
export class EquipmentsPage {
    public user:any;
    public observableVar: any;
    public equipments: any;

  constructor(public navCtrl: NavController,
      public navParams: NavParams,
      public remoteService: RemoteServiceProvider,
      public alertCtrl: AlertController,
      public loading: LoadingController,
      public storage: Storage,
      public toastCtrl: ToastController) {
  }

  ionViewDidLoad() {

  }

  ionViewDidEnter(){
      this.getEquipmentsUser();
  }

  addEquipment(){
      this.navCtrl.push(AddEquipmentsPage);
  }

  updateEquipment(){

  }

  deleteEquipment(equipment){
    console.log(equipment);
    this.remoteService.postApiDeleteEquipmentByIdUseraAndIdEquipmentAndIdZone(equipment.iduser,equipment.idequipment,equipment.idzone)
      .then((response) => {
        if(response == "deleted"){
          this.messageInfo("Eliminado correctamente");
          this.ionViewDidEnter();
        }else{
          this.messageInfo(response);
        }
      });
  }

  details(equipment){
      this.navCtrl.push(EquipmentsDetailsPage,
        {
          equipmentDetails: equipment
        });
  }

  getEquipmentsUser() : any{
      this.storage.get('iduser').then((iduser) => {
          this.observableVar = Subscription;
          this.remoteService.getApiEquipmentsUser(iduser)
          .then(data => {
              /*if(data == false){
                  this.messageInfo("Aun no hay equipos registrados");
              }else{
                this.equipments = data;
              }*/
            this.equipments = data;
          });
      });
  }

  messageInfo(message) {
      let toast = this.toastCtrl.create({
        message: message,
        duration: 3000,
        position: 'buttom'
      });
      toast.onDidDismiss(() => {
      });
      toast.present();
    }
}
