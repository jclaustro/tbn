import { Component } from '@angular/core';
import { IonicPage, NavController, NavParams } from 'ionic-angular';
import { Storage } from '@ionic/storage';

@IonicPage()
@Component({
  selector: 'page-update-account',
  templateUrl: 'update-account.html',
})
export class UpdateAccountPage {

  constructor(public navCtrl: NavController,
              public storage: Storage,
              public navParams: NavParams) {
  }

  email;
  passwordV;
  status;
  iduser;
  company;
  userType;

  ionViewDidLoad() {
    this.storage.get('email').then((val) => {
      this.email = val;
    });

    this.storage.get('company').then((val) => {
      this.company = val;
    });

    this.storage.get('password').then((val) => {
      this.passwordV = val;
    });

    this.storage.get('iduser').then((val) => {
      this.iduser = val;
    });

  }
}
