import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { UpdateAccountPage } from './update-account';

@NgModule({
  declarations: [
    UpdateAccountPage,
  ],
  imports: [
    IonicPageModule.forChild(UpdateAccountPage),
  ],
})
export class UpdateAccountPageModule {}
