import { Component, ViewChild  } from '@angular/core';
import { IonicPage, NavController, NavParams } from 'ionic-angular';
import { RemoteServiceProvider } from '../../providers/remote-service/remote-service';
import {Observable} from 'rxjs/Rx';
import { Subscription } from "rxjs/Subscription";
import { Storage } from '@ionic/storage';
import { ToastController } from 'ionic-angular';
import { StatsDetailsPage } from '../stats-details/stats-details';
import { Chart } from 'chart.js';


@IonicPage()
@Component({
  selector: 'page-stats',
  templateUrl: 'stats.html',
})
export class StatsPage {
  public date = new Date();
  public observableVar: any;
  public equipments: any;
  public data:any;
  public years:any;

  @ViewChild('barCanvas') barCanvas;
  barChart: any;

  constructor(public navCtrl: NavController,
    public navParams: NavParams,
    public remoteService: RemoteServiceProvider,
    public storage: Storage,
    public toastCtrl: ToastController) {
  }

  type;
  totalUse = 0;
  days;
  equipmentsValue = [];
  months;
  totals;
  year;
  ticketType;
  municipalityName;
  energyPrice;

  ionViewDidLoad() {

    this.createChart();
    this.loadChart();
    this.year = this.date.getFullYear();
  }

  ionViewDidEnter() {
    this.createChart();
    this.loadChart();

    this.year = this.date.getFullYear();
    this.storage.get('ticketType').then((ticketType) => {
      this.ticketType = ticketType;
    });

    this.storage.get('municipality').then((municipality) => {
      this.municipalityName = municipality;
    });

    this.storage.get('energyType').then((energyType) => {
      this.remoteService.getApiMunicipalitiesPriceByMunicipalitieNameAndEnergyType(this.municipalityName,energyType)
      .then((response) => {
        this.energyPrice = response[0].price;
        console.log(this.energyPrice);
      });
    });
  }

  createChart(){
      this.barChart = new Chart(this.barCanvas.nativeElement, {
        type: 'bar',
        data: {
            labels: [], //["Ene", "Feb", "Mar", "Abr", "May", "Jun","Jul", "Ago", "Sep", "Oct", "Nov", "Dic"],
            datasets: [{
                label: 'Total',
                data:[],//[200, 250, 30, 50, 20, 30,120, 190, 30, 50, 20, 30],
                backgroundColor: [
                    'rgba(255, 99, 132, 0.2)',
                    'rgba(54, 162, 235, 0.2)',
                    'rgba(255, 206, 86, 0.2)',
                    'rgba(75, 192, 192, 0.2)',
                    'rgba(153, 102, 255, 0.2)',
                    'rgba(255, 159, 64, 0.2)',
                    'rgba(255, 99, 132, 0.2)',
                    'rgba(54, 162, 235, 0.2)',
                    'rgba(255, 206, 86, 0.2)',
                    'rgba(75, 192, 192, 0.2)',
                    'rgba(153, 102, 255, 0.2)',
                    'rgba(255, 159, 64, 0.2)'
                ],
                borderColor: [
                    'rgba(255,99,132,1)',
                    'rgba(54, 162, 235, 1)',
                    'rgba(255, 206, 86, 1)',
                    'rgba(75, 192, 192, 1)',
                    'rgba(153, 102, 255, 1)',
                    'rgba(255, 159, 64, 1)',
                    'rgba(255,99,132,1)',
                    'rgba(54, 162, 235, 1)',
                    'rgba(255, 206, 86, 1)',
                    'rgba(75, 192, 192, 1)',
                    'rgba(153, 102, 255, 1)',
                    'rgba(255, 159, 64, 1)'
                ],
                borderWidth: 1
            }]
        },
        options: {
            scales: {
                yAxes: [{
                    ticks: {
                        beginAtZero:true
                    }
                }]
            }
        }
    });
  }

  loadChart(){
    this.storage.get('iduser').then((iduser) => {
      this.remoteService.getApiUserConsumption(iduser, this.date.getFullYear())
      .then((response) => {
        for(let month of response){
          this.barChart.data.datasets[0].data.push(month.total);
          this.barChart.data.labels.push(month.shortMonthName);
        };
        this.barChart.update();
      });

      this.remoteService.getApiUserYearsOption(iduser)
      .then((response) => {
        this.years = response;
        });
    });
  }

  loadYearChart(year){
    this.storage.get('iduser').then((iduser) => {
      this.remoteService.getApiUserConsumption(iduser,year)
        .then((response) => {
          this.months = [];
          this.totals = [];
          for(let month of response){
            this.totals.push(month.total);
            this.months.push(month.shortMonthName);
          };

          this.barChart.data.labels = this.months;
          this.barChart.data.datasets[0].data = this.totals;
          this.barChart.update();
        })
    });
  }

  calcularConsumo(){
    this.storage.get('iduser').then((iduser) => {
        this.observableVar = Subscription;
        this.remoteService.getApiEquipmentsUser(iduser)
        .then(data => {
            if(data == false){
              this.messageInfo("Aun no hay equipos registrados");
            }else{
              this.equipmentsValue = [];
              this.totalUse = 0;
              this.equipments = data;
              console.log(this.equipments);

              for(let equipment of this.equipments){
                this.equipmentsValue.push({
                    description: equipment.type + " " + equipment.brand + " " +  equipment.model,
                    zone: equipment.zonename,
                    wh: equipment.watts * equipment.averageUse,
                    kw: (equipment.watts * equipment.averageUse)/1000,
                    price: ((equipment.watts * equipment.averageUse)/1000) * this.energyPrice
                  });
                }

                this.totalUse = 0;
                for(var values of this.equipmentsValue){
                  this.totalUse = this.totalUse + values.price
                  }
                  if(this.ticketType == "Mensual" ){
                    this.days = new Date(this.date.getFullYear(), this.date.getMonth() + 1, 0).getDate();
                    this.totalUse = this.totalUse * this.days;
                    this.days = this.days + " dias (1 mes)";
                  }else{
                    var daysMonthOne = new Date(this.date.getFullYear(), this.date.getMonth() + 1, 0).getDate();
                    var daysMonthTwo = new Date(this.date.getFullYear(), this.date.getMonth() + 2, 0).getDate();
                    this.days = daysMonthOne + daysMonthTwo;
                    this.totalUse = this.totalUse * this.days;
                    this.days = this.days + " dias (2 meses)";
                  }
                  this.equipmentsValue.push({
                    total: this.totalUse,
                    days: this.days
                    });

                    this.navCtrl.push(StatsDetailsPage,{
                        statsDetails: this.equipmentsValue
                      });

                this.totalUse = 0;
            }
        });
    });
  }

  messageInfo(message) {
      let toast = this.toastCtrl.create({
        message: message,
        duration: 3000,
        position: 'buttom'
      });
      toast.onDidDismiss(() => {
      });
      toast.present();
    }
}
