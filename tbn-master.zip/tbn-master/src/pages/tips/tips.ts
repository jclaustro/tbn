import { Component } from '@angular/core';
import { IonicPage, NavController, NavParams } from 'ionic-angular';
import { RemoteServiceProvider } from '../../providers/remote-service/remote-service';
import {Observable} from 'rxjs/Rx';
import { Subscription } from "rxjs/Subscription";
import { Storage } from '@ionic/storage';
import { ToastController } from 'ionic-angular';


@IonicPage()
@Component({
  selector: 'page-tips',
  templateUrl: 'tips.html',
})
export class TipsPage {

    public tips:any;
    public observableVar: any;

  constructor(public navCtrl: NavController,
      public navParams: NavParams,
      public remoteService: RemoteServiceProvider,
      public storage: Storage,
      public toastCtrl: ToastController) {
  }

  ionViewDidLoad() {
  }

  ionViewDidEnter(){
      this.postTips();
  }

  postTips() : any{
      this.storage.get('iduser').then((iduser) => {
          this.observableVar = Subscription;
          this.remoteService.postApiTips(iduser)
          .then((response) => {
              if(response == false)
              {
                  this.messageInfo("No hay Tips que mostrar");
              }else{
                this.tips = response;
              }
          });
      });
  }

  messageInfo(message) {
      let toast = this.toastCtrl.create({
        message: message,
        duration: 3000,
        position: 'buttom'
      });
      toast.onDidDismiss(() => {
      });
      toast.present();
    }
}
