import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { EquipmentsDetailsPage } from './equipments-details';

@NgModule({
  declarations: [
    EquipmentsDetailsPage,
  ],
  imports: [
    IonicPageModule.forChild(EquipmentsDetailsPage),
  ],
})
export class EquipmentsDetailsPageModule {}
