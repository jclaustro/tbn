import { Component } from '@angular/core';
import { IonicPage, NavController, NavParams } from 'ionic-angular';

@IonicPage()
@Component({
  selector: 'page-equipments-details',
  templateUrl: 'equipments-details.html',
})
export class EquipmentsDetailsPage {
  public details:any;
  constructor(public navCtrl: NavController, public navParams: NavParams) {
    this.details = this.navParams.get('equipmentDetails');
  }

  ionViewDidLoad() {
    console.log(this.details);
  }

  update(){
    console.log("Update");
  }

}
