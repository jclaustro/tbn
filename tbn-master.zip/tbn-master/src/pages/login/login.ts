import { Component } from '@angular/core';
import { IonicPage, NavController, NavParams } from 'ionic-angular';
import { RemoteServiceProvider } from '../../providers/remote-service/remote-service';
import { AlertController, App} from 'ionic-angular';
import { ToastController } from 'ionic-angular';
import { Storage } from '@ionic/storage';
import { HomePage } from '../home/home';
import { ZonesPage } from '../zones/zones';
import { RegisterPage } from '../register/register';

@IonicPage()
@Component({
  selector: 'page-login',
  templateUrl: 'login.html',
})
export class LoginPage {
  public user: any;
  public status: any;

  constructor(public navCtrl: NavController,
              public navParams: NavParams,
              public remoteService : RemoteServiceProvider,
              public alertCtrl: AlertController,
              private toastCtrl: ToastController,
              public appCtrl: App,
              public storage: Storage) {}

  email;
  pass;

  login(){
    this.remoteService.postApiUserLogin(this.email,this.pass)
      .then((response) => {
        this.user = response;
        if(this.user == false){
          this.messageInfo("El usuario o contraseña estan mal");
        }
        else{
          this.messageInfo("Bienvenido " + this.user[0].email);
          this.storage.set('iduser', this.user[0].iduser);
          this.storage.set('email', this.user[0].email);
          this.storage.set('password', this.user[0].password);
          this.storage.set('company', this.user[0].company);
          this.storage.set('userType',this.user[0].usertype);
          this.storage.set('municipality',this.user[0].municipality);
          this.storage.set('state',this.user[0].state);
          this.storage.set('ticketType',this.user[0].ticketType);
          this.storage.set('energyType',this.user[0].energyType);
          this.storage.set('userStatus', 1);
          this.navCtrl.setRoot(HomePage);
        }
      });
  }

  register(){
    this.navCtrl.push(RegisterPage);
  }

  messageInfo(message){
    let toast = this.toastCtrl.create({
      message: message,
      duration: 3000,
      position: 'buttom'
    });
    toast.onDidDismiss(() => {});
    toast.present();
  }
}
