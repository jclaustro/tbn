import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { StatsDetailsPage } from './stats-details';

@NgModule({
  declarations: [
    StatsDetailsPage,
  ],
  imports: [
    IonicPageModule.forChild(StatsDetailsPage),
  ],
})
export class StatsDetailsPageModule {}
