import { Component } from '@angular/core';
import { IonicPage, NavController, NavParams } from 'ionic-angular';
import { AlertController } from 'ionic-angular';
import { Storage } from '@ionic/storage';
import { RemoteServiceProvider } from '../../providers/remote-service/remote-service';
import {Observable} from 'rxjs/Rx';
import { Subscription } from "rxjs/Subscription";

@IonicPage()
@Component({
  selector: 'page-stats-details',
  templateUrl: 'stats-details.html',
})

export class StatsDetailsPage {
  public details:any;
  public total: any;
  public days:any;
  public date = new Date();
  constructor(public navCtrl: NavController,
              public navParams: NavParams,
              public alertCtrl: AlertController,
              public remoteService: RemoteServiceProvider,
              public storage: Storage) {

    this.details = this.navParams.get('statsDetails');
  }

  ionViewDidLoad() {
    this.total = this.details[this.details.length - 1].total;
    this.total = this.total.toFixed(2);
    this.days = this.details[this.details.length - 1].days;
  }

  saveData(){
      let alert = this.alertCtrl.create({
        title: 'Guardar datos',
        message: '¿Realmente deseas guardar los datos?',
        buttons: [{
            text: 'No',
            role: 'cancel',
            handler: () => {
            }},
          {
            text: 'Si',
            handler: () => {
              this.storage.get('iduser').then((iduser) => {
              let data = {
                iduser: iduser,
                total: parseFloat(this.total),
                idmonth: this.date.getMonth() + 1,
                year: this.date.getFullYear()
              };
                  this.remoteService.postApiAddUserConsumption(data)
                  .then((response) => {
                    console.log(response);
                  });
              });
            }
          }
        ]
      });
      alert.present();
  }
}
