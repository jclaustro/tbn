import { Component } from '@angular/core';
import { Platform } from 'ionic-angular';
import { StatusBar } from '@ionic-native/status-bar';
import { SplashScreen } from '@ionic-native/splash-screen';
import { Storage } from '@ionic/storage';

import { HomePage } from '../pages/home/home';
import { LoginPage } from '../pages/login/login';
import { RegisterPage } from '../pages/register/register';
import { ZonesPage } from '../pages/zones/zones';
import { EquipmentsPage } from '../pages/equipments/equipments';
import { AddEquipmentsPage } from '../pages/add-equipments/add-equipments';
@Component({
  templateUrl: 'app.html'
})
export class MyApp {
  //rootPage:any = HomePage;
  //rootPage:any = LoginPage;
  //rootPage:any = ZonesPage;
  //rootPage:any = EquipmentsPage;
  rootPage:any;

  constructor(platform: Platform,
      statusBar: StatusBar,
      splashScreen: SplashScreen,
      public storage: Storage) {

    platform.ready().then(() => {
      statusBar.styleDefault();
      splashScreen.hide();

      this.storage.get('userStatus').then((val) => {
          //console.log('Your age is', val);
        //this.rootPage = HomePage;
          if(val == 1) {
              this.rootPage = HomePage;
          }
          else{
              //this.rootPage = RegisterPage;
              this.rootPage = LoginPage;
          }
        });
      /*  var sta;
        this.sqlite.create({
          name: 'data.db',
          location: 'default'
        })
          .then((db: SQLiteObject) => {
            db.executeSql('SELECT * FROM user',{})
              .then((data) => {
                let rows = data.rows;
                for(let i = 0; i < rows.length; i++)
                {
                  sta = rows.item(i).status;
                }

                if(sta == 1)
                {
                  self.rootPage = HomePage;
                }
                else
                {
                  self.rootPage = LoginPage
                }
              })
              .catch(e => this.SAlert(e));
          })
          .catch(e => this.SAlert("HOLA"));*/
    });
  }
}
