import { BrowserModule } from '@angular/platform-browser';
import { ErrorHandler, NgModule } from '@angular/core';
import { IonicApp, IonicErrorHandler, IonicModule } from 'ionic-angular';
import { SplashScreen } from '@ionic-native/splash-screen';
import { StatusBar } from '@ionic-native/status-bar';
import { HttpModule } from '@angular/http';

import { MyApp } from './app.component';
import { HomePage } from '../pages/home/home';
import { LoginPage } from '../pages/login/login';
import { ZonesPage } from '../pages/zones/zones';
import { EquipmentsPage } from '../pages/equipments/equipments';
import { AddEquipmentsPage } from '../pages/add-equipments/add-equipments';
import { AddZonesPage } from '../pages/add-zones/add-zones';
import { ZonesDetailsPage } from '../pages/zones-details/zones-details';
import { EquipmentsDetailsPage } from '../pages/equipments-details/equipments-details';
import { InventoryPage } from '../pages/inventory/inventory';
import { InventoryDetailsPage } from '../pages/inventory-details/inventory-details';
import { InventoryDetailsModelPage } from '../pages/inventory-details-model/inventory-details-model';
import { BarcodePage } from '../pages/barcode/barcode';
import { AccountPage } from '../pages/account/account';
import { TipsPage } from '../pages/tips/tips';
import { RegisterPage } from '../pages/register/register';
import { EmployeesPage } from '../pages/employees/employees';
import { AddEmployeePage } from '../pages/add-employee/add-employee';
import { StatsPage } from '../pages/stats/stats';
import { StatsDetailsPage } from '../pages/stats-details/stats-details';
import { UpdateAccountPage } from '../pages/update-account/update-account';

import { RemoteServiceProvider } from '../providers/remote-service/remote-service';
import { BarcodeScanner } from '@ionic-native/barcode-scanner';
import { IonicStorageModule } from '@ionic/storage';

@NgModule({
  declarations: [
    MyApp,
    HomePage,
    LoginPage,
    ZonesPage,
    EquipmentsPage,
    AddEquipmentsPage,
    AddZonesPage,
    ZonesDetailsPage,
    EquipmentsDetailsPage,
    InventoryPage,
    InventoryDetailsPage,
    InventoryDetailsModelPage,
    BarcodePage,
    AccountPage,
    TipsPage,
    RegisterPage,
    EmployeesPage,
    AddEmployeePage,
    StatsPage,
    StatsDetailsPage,
    UpdateAccountPage
  ],
  imports: [
    BrowserModule,
    HttpModule,
    IonicModule.forRoot(MyApp),
    IonicStorageModule.forRoot()
  ],
  bootstrap: [IonicApp],
  entryComponents: [
    MyApp,
    HomePage,
    LoginPage,
    ZonesPage,
    EquipmentsPage,
    AddEquipmentsPage,
    AddZonesPage,
    ZonesDetailsPage,
    EquipmentsDetailsPage,
    InventoryPage,
    InventoryDetailsPage,
    InventoryDetailsModelPage,
    BarcodePage,
    AccountPage,
    TipsPage,
    RegisterPage,
    EmployeesPage,
    AddEmployeePage,
    StatsPage,
    StatsDetailsPage,
    UpdateAccountPage
  ],
  providers: [
    StatusBar,
    SplashScreen,
    BarcodeScanner,
    {provide: ErrorHandler, useClass: IonicErrorHandler},
    RemoteServiceProvider
  ]
})
export class AppModule {}
