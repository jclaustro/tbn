//import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Http, Headers, RequestOptions } from '@angular/http';
import 'rxjs/add/operator/map';
import { Md5 } from 'ts-md5/dist/md5';
import { AlertController, ToastController } from 'ionic-angular';

@Injectable()
export class RemoteServiceProvider {
    private api_key = Md5.hashStr('tbn is awesome');

    private users: any;
    private subusers: any;
    private apiUrlUsers:any;
    private userZones:any;
    private userConsumption;
    private municipalitiPriceEnergy;
    private yearsOptions;
    private userTips:any;
    private brands:any;
    private inventory:any;
    private inventoryDetails: any;
    private zonestype:any;
    private usersType: any;
    private states:any;
    private zonesDetails;
    private equipmentsUser:any;
    private equipmentsTypes:any;
    private municipalities:any;

    private apiUrlUserZones:any;
    private apiUrlFindUser:any;
    private apiUrlEquipmentsUser:any;
    private apiUrlEquipmentsAdd:any;
    private apiUrlZonesDetails:any;
    private apiUrlBrands:any;
    private apiUrlEquipmentsType:any;
    private apiUrlInventory:any;
    private apiUrlInventoryDetails:any;
    private apiUrlValidateUser:any;
    private apiUrlUserRegister:any;
    private apiUrlAddZones:any;
    private apiUrlSearchEquipment:any;
    private apiUrlTips:any;
    private apiUrlAddSubUsers:any;
    private apiUrlSubUsers:any;
    private apiUrlZonesType:any;
    private apiUrlUsersType: any;
    private apiUrlStates: any;
    private apiUrlMunicipalities:any;
    private apiUrlUserConsumption:any;
    private apiUrlUserYearsOption:any;
    private apiUrlAddUserConsumption: any;
    private apiUrlMunicipalityPrice: any;
    private apiUrlDeleteSubUser: any;
    private apiUrlDeleteZone: any;
    private apiUrlDeleteEquipment: any;


  constructor(public http: Http, public alertCtrl: AlertController, public toastCtrl: ToastController) {
    //const server_domain = "http://tbn-api/api/";
    //const erver_domain = "http://148.202.23.36/api/";
    const server_domain = "http://localhost:8000/api/";

    this.apiUrlUserZones = server_domain + "user/zones/";
    this.apiUrlFindUser = server_domain + "login";
    this.apiUrlEquipmentsUser = server_domain + "user/equipments/";
    this.apiUrlEquipmentsAdd = server_domain + "user/equipments/add";
    this.apiUrlAddZones = server_domain + "user/zones/add";
    this.apiUrlEquipmentsType = server_domain + "equipments/type/";
    this.apiUrlZonesType = server_domain + "zones/type/";
    this.apiUrlBrands = server_domain + "equipments/brands/";
    this.apiUrlUserRegister = server_domain + "register";
    this.apiUrlSearchEquipment = server_domain + "equipments/search";
    this.apiUrlZonesDetails = server_domain + "zones/details/";
    this.apiUrlInventory = server_domain + "users/equipments/inventory/"
    this.apiUrlInventoryDetails = server_domain + "users/equipments/inventory/details/";
    this.apiUrlTips = server_domain + "users/tips";
    this.apiUrlAddSubUsers = server_domain + "users/subusers/add";
    this.apiUrlSubUsers = server_domain + "users/subusers/";
    this.apiUrlUsersType = server_domain + "users/type/";
    this.apiUrlStates = server_domain + "register/states/";
    this.apiUrlMunicipalities = server_domain + "register/states/municipalities/";
    this.apiUrlUserConsumption = server_domain + "users/userConsumption/";
    this.apiUrlUserYearsOption = server_domain + "users/years/";
    this.apiUrlAddUserConsumption = server_domain + "users/consumption/add";
    this.apiUrlMunicipalityPrice = server_domain + "users/municipalities/price/";
    this.apiUrlDeleteSubUser = server_domain + "users/subusers/delete";
    this.apiUrlDeleteZone = server_domain + "users/zones/delete";
    this.apiUrlDeleteEquipment = server_domain + "user/equipments/delete";
  }

  public getApiUsers() : any{
    return new Promise(resolve => {
      this.http.get(this.apiUrlUsers)
        .map(res => res.json())
        .subscribe(data => {
          this.users = data;
          resolve(this.users);
      },
      error => {
          if(error.status == 0){
              this.noInternet();
          }
      });
    });
  }

  public getApiUserZones(user) : any{
    return new Promise(resolve => {
      let url = this.apiUrlUserZones + user + "/" + this.api_key;
      this.http.get(url)
        .map(res => res.json())
        .subscribe(data => {
          this.userZones = data;
          resolve(this.userZones);
      },
      error => {
          if(error.status == 0){
              this.noInternet();
          }
      });
    });
  }

  public getApiEquipmentsUser(user) : any{
    return new Promise(resolve => {
      let url = this.apiUrlEquipmentsUser + user + "/" + this.api_key;
      this.http.get(url)
        .map(res => res.json())
        .subscribe(data => {
          this.equipmentsUser = data;
          resolve(this.equipmentsUser);
      },
      error => {
          if(error.status == 0){
              this.noInternet();
          }
      });
    });
  }

  public getApiBrands() : any{
    return new Promise(resolve => {
      let url = this.apiUrlBrands + this.api_key;
      this.http.get(url)
        .map(res => res.json())
        .subscribe(data => {
          this.brands = data;
          resolve(this.brands);
      },
      error => {
          if(error.status == 0){
              this.noInternet();
          }
      });
    });
  }

  public getApiEquipmentsType() : any{
    return new Promise(resolve => {
      let url = this.apiUrlEquipmentsType + this.api_key;
      this.http.get(url)
        .map(res => res.json())
        .subscribe(data => {
          this.equipmentsTypes = data;
          resolve(this.equipmentsTypes);
      },
      error => {
          if(error.status == 0){
              this.noInternet();
          }
      });
    });
  }

  public getApiZonesType() : any{
    return new Promise(resolve => {
      let url = this.apiUrlZonesType + this.api_key;
      this.http.get(url)
        .map(res => res.json())
        .subscribe(data => {
          this.zonestype = data;
          resolve(this.zonestype);
      },
      error => {
          if(error.status == 0){
              this.noInternet();
          }
      });
    });
  }

  public getApiUsersType() : any{
    return new Promise(resolve => {
      let url = this.apiUrlUsersType + this.api_key;
      this.http.get(url)
        .map(res => res.json())
        .subscribe(data => {
          this.usersType = data;
          resolve(this.usersType);
      },
      error => {
          if(error.status == 0){
              this.noInternet();
          }
      });
    });
  }

  public getApiStates() : any{
    return new Promise(resolve => {
      let url = this.apiUrlStates + this.api_key;
      this.http.get(url)
        .map(res => res.json())
        .subscribe(data => {
          this.states = data;
          resolve(this.states);
      },
      error => {
          if(error.status == 0){
              this.noInternet();
          }
      });
    });
  }

  public async postApiUserLogin(email, pass): Promise<any>{
    try{
      let headers = new Headers();
      headers.append('Content-Type', 'application/x-www-form-urlencoded');
      let options = new RequestOptions({ headers: headers });
      let body = "email="+email+"&password="+pass;
      const response = await this.http.post(this.apiUrlFindUser,body,options).toPromise();
      return response.json();
    } catch(err){
      throw new Error(err.status);
      }
    }

    public async postApiAddZones(iduser, zonename, zonetype): Promise<any>{
      try{
        let headers = new Headers();
        headers.append('Content-Type', 'application/x-www-form-urlencoded');
        let options = new RequestOptions({ headers: headers });
        let body = "iduser="+iduser+"&zonename="+zonename+"&zonetype="+zonetype;
        const response = await this.http.post(this.apiUrlAddZones,body,options).toPromise();
        return response.json();
      } catch(err){
        throw new Error(err.status);
      }
    }

    public async postApiAddEquipment(equipment,iduser): Promise<any>{
      try{
        let headers = new Headers();
        headers.append('Content-Type', 'application/x-www-form-urlencoded');
        let options = new RequestOptions({ headers: headers });
        let body = "type="+equipment.type+"&brand="+equipment.brand+"&barcode="+ equipment.barcode+"&model="+equipment.model+
        "&dcinput="+equipment.dcinput+"&dcoutput="+equipment.dcoutput+"&watts="+equipment.watts+"&use="+equipment.use+
        "&amperes="+equipment.amperes+"&zone="+equipment.zone+"&iduser="+iduser;
        console.log(equipment);
        const response = await this.http.post(this.apiUrlEquipmentsAdd,body,options).toPromise();
        return response.json();
      } catch(err){
        throw new Error(err.status);
      }
    }

    public async postApiUserRegister(email, pass, company,state,municipality,type,ticket): Promise<any>{
      try{
        let headers = new Headers();
        headers.append('Content-Type', 'application/x-www-form-urlencoded');
        let options = new RequestOptions({ headers: headers });
        let body = "email="+email+"&password="+pass+"&company="+company+"&state="+state+"&municipality="+municipality+"&type="+type+"&ticket="+ticket;
        const response = await this.http.post(this.apiUrlUserRegister,body,options).toPromise();
        return response.json();
      } catch(err){
        throw new Error(err.status);
      }
    }

    public async postApiSubUsers(iduser): Promise<any>{
      try{
        let headers = new Headers();
        headers.append('Content-Type', 'application/x-www-form-urlencoded');
        let options = new RequestOptions({ headers: headers });
        let body = "iduser="+iduser;
        const response = await this.http.post(this.apiUrlSubUsers,body,options).toPromise();
        return response.json();
      } catch(err){
        throw new Error(err.status);
      }
    }

  public getApiSubUsers(iduser) : any{
    return new Promise(resolve => {
      let url = this.apiUrlSubUsers + iduser + "/" + this.api_key;
      console.log(url);
      this.http.get(url)
        .map(res => res.json())
        .subscribe(data => {
            this.subusers = data;
            resolve(this.subusers);
          },
          error => {
            if(error.status == 0){
              this.noInternet();
            }
          });
    });
  }

    public async postApiAddSubUsers(employee): Promise<any>{
      try{
        let headers = new Headers();
        headers.append('Content-Type', 'application/x-www-form-urlencoded');
        let options = new RequestOptions({ headers: headers });
        let body = "email="+employee.email+"&password="+employee.password+"&company="+employee.company+"&iduser="+employee.iduser+"&usertype="+employee.type;
        const response = await this.http.post(this.apiUrlAddSubUsers,body,options).toPromise();
        return response.json();
      } catch(err){
        throw new Error(err.status);
      }
    }

    public async postValidateUser(email): Promise<any>{
      try{
        let headers = new Headers();
        headers.append('Content-Type', 'application/x-www-form-urlencoded');
        let options = new RequestOptions({ headers: headers });
        let body = "email="+email;
        const response = await this.http.post(this.apiUrlValidateUser,body,options).toPromise();
        return response.json();
      } catch(err){
        throw new Error(err.status);
      }
    }

    public async postApiInventoryDetails(email, type): Promise<any>{
      try{
        let headers = new Headers();
        headers.append('Content-Type', 'application/x-www-form-urlencoded');
        let options = new RequestOptions({ headers: headers });
        let body = "email="+email+"&type="+type;
        const response = await this.http.post(this.apiUrlInventoryDetails,body,options).toPromise();
        return response.json();
      } catch(err){
        throw new Error(err.status);
      }
    }

    public getApiInventoryDetails(iduser , equipmentType) : any{
      return new Promise(resolve => {
        let url = this.apiUrlInventoryDetails + iduser + "/" + equipmentType + "/" + this.api_key;
        console.log(url);
        this.http.get(url)
          .map(res => res.json())
          .subscribe(data => {
              this.inventoryDetails = data;
              resolve(this.inventoryDetails);
            },
            error => {
              if(error.status == 0){
                this.noInternet();
              }
            });
      });
    }

    public async postApiInventory(email): Promise<any>{
      try{
        let headers = new Headers();
        headers.append('Content-Type', 'application/x-www-form-urlencoded');
        let options = new RequestOptions({ headers: headers });
        let body = "email="+email;
        const response = await this.http.post(this.apiUrlInventory,body,options).toPromise();
        return response.json();
      } catch(err){
        throw new Error(err.status);
      }
    }

    public getApiInventory(iduser) : any{
      return new Promise(resolve => {
        let url = this.apiUrlInventory + iduser + "/" + this.api_key;
        console.log(url);
        this.http.get(url)
          .map(res => res.json())
          .subscribe(data => {
              this.inventory = data;
              resolve(this.inventory);
            },
            error => {
              if(error.status == 0){
                this.noInternet();
              }
            });
      });
    }

    public async postApiTips(iduser): Promise<any>{
      try{
        let headers = new Headers();
        headers.append('Content-Type', 'application/x-www-form-urlencoded');
        let options = new RequestOptions({ headers: headers });
        let body = "iduser="+iduser;
        const response = await this.http.post(this.apiUrlTips,body,options).toPromise();
        return response.json();
      } catch(err){
        throw new Error(err.status);
      }
    }

  public getApiTips(user) : any{
    return new Promise(resolve => {
      let url = this.apiUrlTips + user + "/" + this.api_key;
      this.http.get(url)
        .map(res => res.json())
        .subscribe(data => {
            this.userTips = data;
            resolve(this.userTips);
          },
          error => {
            if(error.status == 0){
              this.noInternet();
            }
          });
    });
  }

    public async postApiZonesDetails(email, zonename): Promise<any>{
      try{
        let headers = new Headers();
        headers.append('Content-Type', 'application/x-www-form-urlencoded');
        let options = new RequestOptions({ headers: headers });
        let body = "email="+email+"&zonename="+zonename;
        const response = await this.http.post(this.apiUrlZonesDetails,body,options).toPromise();
        return response.json();
      } catch(err){
        throw new Error(err.status);
      }
    }

  public getApiZonesDetails(user, zonename) : any{
    return new Promise(resolve => {
      let url = this.apiUrlZonesDetails + user + "/"  + zonename + "/" +  this.api_key;
      console.log(url);
      this.http.get(url)
        .map(res => res.json())
        .subscribe(data => {
            this.zonesDetails = data;
            resolve(this.zonesDetails);
          },
          error => {
            if(error.status == 0){
              this.noInternet();
            }
          });
    });
  }

    public async postApiSearchEquipment(barcode, model): Promise<any>{
      try{
        let headers = new Headers();
        headers.append('Content-Type', 'application/x-www-form-urlencoded');
        let options = new RequestOptions({ headers: headers });
        let body = "barcode="+barcode+"&model="+model;
        const response = await this.http.post(this.apiUrlSearchEquipment,body,options).toPromise();
        return response.json();
      } catch(err){
        throw new Error(err.status);
      }
    }

    public async postApiMunicupalities(idstate): Promise<any>{
      try{
        let headers = new Headers();
        headers.append('Content-Type', 'application/x-www-form-urlencoded');
        let options = new RequestOptions({ headers: headers });
        let body = "idstate="+idstate;
        const response = await this.http.post(this.apiUrlMunicipalities,body,options).toPromise();
        return response.json();
      } catch(err){
        throw new Error(err.status);
      }
    }

  public getApiMunicipalitiesByIdState(idState) : any{
    return new Promise(resolve => {
      let url = this.apiUrlMunicipalities + idState + "/" + this.api_key;
      this.http.get(url)
        .map(res => res.json())
        .subscribe(data => {
            this.municipalities = data;
            resolve(this.municipalities);
          },
          error => {
            if(error.status == 0){
              this.noInternet();
            }
          });
    });
  }

    public async postApiUserConsumption(iduser,year): Promise<any>{
      try{
        let headers = new Headers();
        headers.append('Content-Type', 'application/x-www-form-urlencoded');
        let options = new RequestOptions({ headers: headers });
        let body = "iduser="+iduser+"&year="+year;
        const response = await this.http.post(this.apiUrlUserConsumption,body,options).toPromise();
        return response.json();
      } catch(err){
        throw new Error(err.status);
      }
    }

  public getApiUserConsumption(iduser,year) : any{
    return new Promise(resolve => {
      let url = this.apiUrlUserConsumption + iduser + "/" + year + "/" + this.api_key;
      this.http.get(url)
        .map(res => res.json())
        .subscribe(data => {
            this.userConsumption = data;
            resolve(this.userConsumption);
          },
          error => {
            if(error.status == 0){
              this.noInternet();
            }
          });
    });
  }

    public async postApiUserYearsOption(iduser): Promise<any>{
      try{
        let headers = new Headers();
        headers.append('Content-Type', 'application/x-www-form-urlencoded');
        let options = new RequestOptions({ headers: headers });
        let body = "iduser="+iduser;
        const response = await this.http.post(this.apiUrlUserYearsOption,body,options).toPromise();
        return response.json();
      } catch(err){
        throw new Error(err.status);
      }
    }

  public getApiUserYearsOption(user) : any{
    return new Promise(resolve => {
      let url = this.apiUrlUserYearsOption + user + "/" + this.api_key;
      this.http.get(url)
        .map(res => res.json())
        .subscribe(data => {
            this.yearsOptions = data;
            resolve(this.yearsOptions);
          },
          error => {
            if(error.status == 0){
              this.noInternet();
            }
          });
    });
  }

    public async postApiAddUserConsumption(data): Promise<any>{
      try{
        let headers = new Headers();
        headers.append('Content-Type', 'application/x-www-form-urlencoded');
        let options = new RequestOptions({ headers: headers });
        let body = "iduser="+data.iduser+"&total="+data.total+"&idmonth="+data.idmonth+"&year="+data.year;
        const response = await this.http.post(this.apiUrlAddUserConsumption,body,options).toPromise();
        return response.json();
      } catch(err){
        throw new Error(err.status);
      }
    }

    public async postApiMunicupalitiesPrice(energyType,municipalityname): Promise<any>{
      try{
        let headers = new Headers();
        headers.append('Content-Type', 'application/x-www-form-urlencoded');
        let options = new RequestOptions({ headers: headers });
        let body = "energyType="+energyType+"Price"+"&municipalityname="+municipalityname;
        const response = await this.http.post(this.apiUrlMunicipalityPrice,body,options).toPromise();
        return response.json();
      } catch(err){
        throw new Error(err.status);
      }
    }

  public getApiMunicipalitiesPriceByMunicipalitieNameAndEnergyType(municipality, energy) : any{
    return new Promise(resolve => {
      let url = this.apiUrlMunicipalityPrice + municipality + "/" + energy + "/" + this.api_key;
      this.http.get(url)
        .map(res => res.json())
        .subscribe(data => {
            this.municipalitiPriceEnergy = data;
            resolve(this.municipalitiPriceEnergy);
          },
          error => {
            if(error.status == 0){
              this.noInternet();
            }
          });
    });
  }

  public async postApiDeleteSubUserByIdSubUser(idsubuser): Promise<any>{
    try{
      let headers = new Headers();
      headers.append('Content-Type', 'application/x-www-form-urlencoded');
      let options = new RequestOptions({ headers: headers });
      let body = "idsubuser="+idsubuser;
      const response = await this.http.post(this.apiUrlDeleteSubUser,body,options).toPromise();
      return response.json();
    } catch(err){
      throw new Error(err.status);
    }
  }

  public async postApiDeleteZoneByIdZone(idzone): Promise<any>{
    try{
      let headers = new Headers();
      headers.append('Content-Type', 'application/x-www-form-urlencoded');
      let options = new RequestOptions({ headers: headers });
      let body = "idzone="+idzone;
      const response = await this.http.post(this.apiUrlDeleteZone,body,options).toPromise();
      return response.json();
    } catch(err){
      throw new Error(err.status);
    }
  }

  public async postApiDeleteEquipmentByIdUseraAndIdEquipmentAndIdZone(iduser,idquipment,idzone): Promise<any>{
    try{
      let headers = new Headers();
      headers.append('Content-Type', 'application/x-www-form-urlencoded');
      let options = new RequestOptions({ headers: headers });
      let body = "iduser="+iduser+"&idquipment="+idquipment+"&idzone="+idzone;
      const response = await this.http.post(this.apiUrlDeleteEquipment,body,options).toPromise();
      return response.json();
    } catch(err){
      throw new Error(err.status);
    }
  }

  private noInternet() {
    let toast = this.toastCtrl.create({
      message: 'Es necesario tener acceso a internet para poder ver el contenido',
      duration: 3000,
      position: 'bottom'
    });
    toast.present(toast);
  }

}
